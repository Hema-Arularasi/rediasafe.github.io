from flask import Flask, request, jsonify, redirect, url_for
import joblib
import numpy as np
import os 
import pandas as pd
from flask_cors import CORS
import google.generativeai as genai
import pytesseract
import re
from PIL import Image
import pymupdf as fitz
from pymongo import MongoClient
from passlib.context import CryptContext
import random
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import smtplib


app = Flask(__name__)
CORS(app)
otp_storage = {}
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_EMAIL = "kathiroli216@gmail.com"  
SMTP_PASSWORD = "idxj aizy pdew zctp"
client = MongoClient("mongodb://localhost:27017/")
db = client["USERS"]
users_collection = db["users"]
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

genai.configure(api_key='AIzaSyBQ7txEHBMR-cFT1j1kXDnTH7ukuWOp7NY')

MODEL_PATH = os.path.join('model', 'diabetes_readmission_model_lgb.pkl')
generative_model = genai.GenerativeModel("gemini-1.5-flash")

model = joblib.load(MODEL_PATH)
  
chat = generative_model.start_chat(
    history=[
        {"role": "model", "parts": ["Hello! How can I assist you today?"]},
    ]
)

features = ['age', 'gender', 'time_in_hospital', 'num_medications', 
             'insulin_treatment', 'A1C_result', 'preceding_year_visits']

@app.route('/predict', methods=['POST'])
def predict():
    try:
        
        data = request.get_json()

        
        age = data['age']
        gender = data['gender']
        time_in_hospital = data['time_in_hospital']
        num_medications = data['num_medications']
        insulin_treatment = data['insulin_treatment']
        a1c_result = data['a1c_result']
        preceding_year_visits = data['preceding_year_visits']

        
        input_data = pd.DataFrame([[age, gender, time_in_hospital, num_medications, insulin_treatment, a1c_result, preceding_year_visits]],
                                  columns=features)
        
        
        prediction_proba = model.predict_proba(input_data)[0][1] * 100

        
        if prediction_proba < 30:
            risk_level = 'Low Risk'
        elif prediction_proba < 70:
            risk_level = 'Medium Risk'
        else:
            risk_level = 'High Risk'

        
        return jsonify({'risk_score': prediction_proba, 'risk_level': risk_level})

    except Exception as e:
        
        return jsonify({'error': str(e)}), 400


def analyze_risk_and_provide_suggestions(risk_level):
    if risk_level.lower() == "high": 
        return (
            "Adopt a healthier lifestyle immediately. Change your diet, increase physical activity, "
            "and consult with a healthcare professional regularly."
        )
    elif risk_level.lower() == "medium":
        return (
            "Maintain a balanced diet and regular exercise. Regular checkups with your healthcare provider are recommended."
        )
    elif risk_level.lower() == "low":
        return "Continue maintaining a healthy lifestyle with regular checkups."
    else:
        return "Invalid risk level provided."

@app.route('/chat', methods=['POST'])
def chat_with_gemini():
    try:
        data = request.json
        user_input = data.get('user_input')
        risk_level = data.get('risk_level')

        
        if not user_input:
            return jsonify({'error': 'user_input is required'}), 400

        gemini_response = ""
        suggestions = None

        
        if risk_level and risk_level.lower() in ['low', 'medium', 'high']:
            suggestions = analyze_risk_and_provide_suggestions(risk_level)

        
        try:
            response = chat.send_message(user_input)
            gemini_response = response.text
        except Exception as e:
            gemini_response = f"An error occurred while connecting to Gemini: {str(e)}"
            app.logger.error(gemini_response)

        
        response_data = {'gemini_response': gemini_response}


        if suggestions:
            response_data['suggestions'] = suggestions

        return jsonify(response_data)

    except Exception as e:
        error_message = f"Server error: {str(e)}"
        app.logger.error(error_message)
        return jsonify({'error': error_message}), 500


def extract_text_from_image(image_path):
    image = Image.open(image_path)
    text = pytesseract.image_to_string(image)
    return text


def extract_text_from_pdf(pdf_path):
    text = ""
    document = fitz.open(pdf_path)
    for page_num in range(len(document)):
        page = document.load_page(page_num)
        text += page.get_text()
    return text

def extract_text_from_file(file_path):
    if file_path.lower().endswith(('.png', '.jpg', '.jpeg')):
        return extract_text_from_image(file_path)
    elif file_path.lower().endswith('.pdf'):
        return extract_text_from_pdf(file_path)
    else:
        raise ValueError("Unsupported file format. Please upload a JPEG, PNG, JPG, or PDF file.")

def parse_diabetes_report(extracted_text):
    def extract_value(pattern, text):
        match = re.search(pattern, text, re.IGNORECASE)
        return match.group(1).strip() if match else 'Not Found'
    
    patterns = {
        'Age': r'\bAge\s*[:\-]?\s*(\d+)',
        'Gender': r'\bGender\s*(?:\(0\s*for\s*Male\s*,\s*1\s*for\s*Female\))?\s*[:\-]?\s*(0|1)|\bGender\s*[:\-]?\s*(0|1)',
        'Time in Hospital (days)': r'\bTime\s*in\s*Hospital\s*(?:\(days\))?\s*[:\-]?\s*(\d+)',
        'Number of Medications': r'\bNumber\s*of\s*Medications\s*[:\-]?\s*(\d+)',
        'Insulin Treatment': r'\bInsulin\s*Treatment\s*(?:\(0\s*for\s*No\s*,\s*1\s*for\s*Yes\))?\s*[:\-]?\s*(0|1)|\bInsulin\s*Treatment\s*[:\-]?\s*(0|1)',
        'A1C Result': r'\bA1C\s*Result\s*(?:\(0\s*for\s*Normal\s*,\s*1\s*for\s*Abnormal\))?\s*[:\-]?\s*(0|1)|\bA1C\s*Result\s*[:\-]?\s*(0|1)',
        'Number of Preceding Year Visits': r'\bNumber\s*of\s*Preceding\s*Year\s*Visits\s*[:\-]?\s*(\d+)'
    }
    
    parsed_data = {key: extract_value(pattern, extracted_text) for key, pattern in patterns.items()}
    
    
    print("Parsed Data:", parsed_data)
    
    return parsed_data

def predict_readmission(file_path):
    
    extracted_text = extract_text_from_file(file_path)
    
    
    print("Extracted Text:\n", extracted_text)
    
    
    parsed_data = parse_diabetes_report(extracted_text)
    
    
    for key in parsed_data:
        if parsed_data[key] == "Not Found" or parsed_data[key] is None:
            parsed_data[key] = 0  
        else:
            try:
                
                if key in ['Age', 'Time in Hospital (days)', 'Number of Medications', 'Number of Preceding Year Visits']:
                    parsed_data[key] = int(parsed_data[key])
                else:
                   
                    parsed_data[key] = 1 if parsed_data[key] in ['1', 'Abnormal'] else 0
            except ValueError:
                parsed_data[key] = 0  

    
    model_path = os.path.join('model', 'diabetes_readmission_model_lgb.pkl')
    model = joblib.load(model_path)
    
    
    df = pd.DataFrame([parsed_data])
    
    
    prediction_proba = model.predict_proba(df)[0][1] * 100
    
    
    if prediction_proba < 30:
        risk_level = 'Low Risk'
    elif prediction_proba < 70:
        risk_level = 'Medium Risk'
    else:
        risk_level = 'High Risk'

    return {
        'risk_score': prediction_proba,
        'risk_level': risk_level,
        'parsed_data': parsed_data
    }

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'medical_image' not in request.files:
        return jsonify({'error': 'No file provided'}), 400

    file = request.files['medical_image']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    if file:
        
        file_path = os.path.join('uploads', file.filename)
        file.save(file_path)
        
        
        try:
            result = predict_readmission(file_path)
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        
        
        os.remove(file_path)
        
        return jsonify(result)
    
@app.route("/signup", methods=["POST"])
def signup():
    data = request.json
    name = data.get("name")
    username = data.get("username")
    email = data.get("email")
    password = data.get("password")

    
    if users_collection.find_one({"username": username}):
        
        suggested_username = username + str(random.randint(100, 999))
        return jsonify({"detail": "Username already exists", "suggestion": suggested_username}), 400

    if users_collection.find_one({"email": email}):
        return jsonify({"detail": "Email already exists"}), 400

    
    hashed_password = pwd_context.hash(password)

    
    user_data = {
        "name": name,
        "username": username,
        "email": email,
        "password": hashed_password,
    }
    users_collection.insert_one(user_data)

    return jsonify({"message": "User created successfully"}), 201


@app.route("/login", methods=["POST"])
def login():
    data = request.json
    username = data.get("username")
    password = data.get("password")

    
    user = users_collection.find_one({"username": username})
    if not user:
        return jsonify({"detail": "Invalid username or password"}), 401

    
    if not pwd_context.verify(password, user["password"]):
        return jsonify({"detail": "Invalid username or password"}), 401

    
    return jsonify({"message": "Login successful"}), 200

# Prediction route (only accessible if logged in)
@app.route("/predictions", methods=["GET"])
def predictions():
    # This route should be protected, implement a session or token check here
    # For simplicity, it's left open
    return jsonify({"prediction": "Your prediction data here"}), 200


def send_otp_email(email, otp):
    message = MIMEMultipart()
    message["From"] = SMTP_EMAIL
    message["To"] = email
    message["Subject"] = "Your OTP Code"

    body = f"Your OTP code is {otp}. Please use this code to complete your signup."
    message.attach(MIMEText(body, "plain"))

    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SMTP_EMAIL, SMTP_PASSWORD)
        server.sendmail(SMTP_EMAIL, email, message.as_string())
        server.quit()
        print(f"OTP sent to {email}")
    except Exception as e:
        print(f"Failed to send email: {e}")

@app.route("/verify-email", methods=["POST"])
def verify_email():
    data = request.json
    email = data.get("email")

    if users_collection.find_one({"email": email}):
        return jsonify({"detail": "Email already exists"}), 400

    otp = str(random.randint(100000, 999999))
    otp_storage[email] = otp

    # Send OTP to email
    send_otp_email(email, otp)

    return jsonify({"message": "OTP sent"}), 200

@app.route("/verify-otp", methods=["POST"])
def verify_otp():
    data = request.json
    email = request.json.get("email")
    otp = data.get("otp")

    stored_otp = otp_storage.get(email)
    print(f"Stored OTP: {stored_otp}, Entered OTP: {otp}")  

    if stored_otp == otp:
        del otp_storage[email]
        return jsonify({"message": "OTP verified successfully"}), 200
    else:
        return jsonify({"message": "Invalid OTP"}), 400
    

    
if __name__ == '__main__':
    app.run(debug=True)