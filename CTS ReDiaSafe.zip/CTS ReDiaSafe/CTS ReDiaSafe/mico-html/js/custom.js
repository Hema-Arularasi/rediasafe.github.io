// to get current year
function getYear() {
    var currentDate = new Date();
    var currentYear = currentDate.getFullYear();
    document.querySelector("#displayYear").innerHTML = currentYear;
}

getYear();

// nice select
$(document).ready(function () {
    $('select').niceSelect();
});

// date picker
$(function () {
    $("#inputDate").datepicker({
        autoclose: true,
        todayHighlight: true
    }).datepicker('update', new Date());
});

// owl carousel slider js
$('.team_carousel').owlCarousel({
    loop: true,
    margin: 15,
    dots: true,
    autoplay: true,
    navText: [
        '<i class="fa fa-angle-left" aria-hidden="true"></i>',
        '<i class="fa fa-angle-right" aria-hidden="true"></i>'
    ],
    autoplayHoverPause: true,
    responsive: {
        0: {
            items: 1,
            margin: 0
        },
        576: {
            items: 2,
        },
        992: {
            items: 3
        }
    }
})

function predictRisk() {
    // Gather form data
    const patientAge = document.getElementById('patient_age').value;
    const gender = document.getElementById('gender').value;
    const timeInHospital = document.getElementById('time_in_hospital').value;
    const numMedications = document.getElementById('num_medications').value;
    const insulinTreatment = document.getElementById('insulin_treatment').value;
    const a1cResult = document.getElementById('a1c_result').value;
    const precedingYearVisits = document.getElementById('preceding_year_visits').value;

    // Prepare the data to send
    const data = {
        age: parseInt(patientAge, 10),
        gender: parseInt(gender, 10),
        time_in_hospital: parseInt(timeInHospital, 10),
        num_medications: parseInt(numMedications, 10),
        insulin_treatment: parseInt(insulinTreatment, 10),
        a1c_result: parseInt(a1cResult, 10),
        preceding_year_visits: parseInt(precedingYearVisits, 10)
    };

    // Make the POST request to the server
    fetch('http://127.0.0.1:5000/predict', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        // Check if the response contains the risk score
        if (data && data.risk_score !== undefined) {
            document.getElementById('riskScore').textContent = data.risk_score.toFixed(2);
            document.getElementById('risk_level').textContent = data.risk_level;
            document.getElementById('resultContainer').style.display = 'block';
        } else {
            console.error('Unexpected response format:', data);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}
document.addEventListener("DOMContentLoaded", function () {
    const isLoggedIn = localStorage.getItem("isLoggedIn");

    // Check login status when the Prediction link is clicked
    document.getElementById("predictionLink").addEventListener("click", function (e) {
      if (!isLoggedIn) {
        e.preventDefault();
        alert("You must be logged in to access the Prediction page.");
        window.location.href = "login.html";
      }
    });
  });